package com.github.midros.istheapp.data.model

import java.io.Serializable

/**
 * Created by luis rafael on 28/03/18.
 */
data class Child(val name:String,val photoUrl:String?,val nameDevice:String) : Serializable