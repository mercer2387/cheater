package com.github.midros.istheapp.services.sms

import com.github.midros.istheapp.services.base.InterfaceService

/**
 * Created by luis rafael on 27/03/18.
 */
interface InterfaceServiceSms : InterfaceService {

    fun stopServiceSms()

}