package com.github.midros.istheapp.ui.activities.register

import com.github.midros.istheapp.ui.activities.base.InterfaceView

/**
 * Created by luis rafael on 10/03/18.
 */
interface InterfaceViewRegister : InterfaceView