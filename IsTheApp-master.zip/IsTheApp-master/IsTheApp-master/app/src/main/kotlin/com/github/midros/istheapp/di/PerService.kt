package com.github.midros.istheapp.di

import javax.inject.Scope

/**
 * Created by luis rafael on 15/03/18.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class PerService